# Job Portal Management System

A full-stack web application built with **Spring Boot**, **Spring Security**, **Spring Data JPA**, and **Thymeleaf**.

## Features

### Student / Job Seeker
- Register, login, and manage profile
- Upload resume (PDF/DOC)
- Browse and search jobs by keyword, category, location, experience
- Apply for jobs with a cover letter
- Track application status (Pending → Shortlisted → Hired/Rejected)
- Email notification when shortlisted

### Employer
- Post, edit, and delete job listings
- View all applicants per job
- Shortlist, hire, or reject candidates

### Admin
- Dashboard analytics (users, jobs, applications, shortlisted)
- Manage all users and jobs

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Spring Boot 3.2, Spring MVC |
| Security | Spring Security 6 (BCrypt, role-based) |
| Database | Spring Data JPA + H2 (dev) / MySQL (prod) |
| Frontend | Thymeleaf, HTML5, CSS3, JavaScript ES6 |
| File Upload | Spring MultipartFile |
| Email | Spring Mail (JavaMailSender) |

## Quick Start

### Prerequisites
- Java 17+
- Maven 3.8+

### Run with H2 (in-memory, no setup needed)
```bash
mvn spring-boot:run
```

Open: http://localhost:8080

### Demo Credentials
| Role | Email | Password |
|------|-------|----------|
| Student | student@example.com | student123 |
| Employer | employer@techcorp.com | employer123 |
| Admin | admin@jobportal.com | admin123 |

### Switch to MySQL
1. Create database: `CREATE DATABASE jobportaldb;`
2. In `application.properties`, comment out H2 lines and uncomment MySQL lines
3. Update `spring.datasource.username` and `spring.datasource.password`

### Email Notifications (Optional)
Update in `application.properties`:
```properties
spring.mail.username=your-email@gmail.com
spring.mail.password=your-app-password
```
Use a Gmail App Password (not your regular password).

## Project Structure
```
src/main/java/com/jobportal/
├── config/          # Security, DataInitializer
├── controller/      # Auth, Job, Student, Employer, Admin
├── entity/          # User, Job, Application
├── exception/       # GlobalExceptionHandler
├── repository/      # JPA repositories
└── service/         # Business logic + EmailService

src/main/resources/
├── templates/       # Thymeleaf HTML templates
│   ├── auth/        # login, register
│   ├── jobs/        # list, detail
│   ├── student/     # dashboard, profile, apply, applications
│   ├── employer/    # dashboard, job-form, applicants
│   └── admin/       # dashboard, users, jobs
└── static/
    ├── css/style.css
    └── js/main.js
```

## H2 Console
Available at: http://localhost:8080/h2-console  
JDBC URL: `jdbc:h2:mem:jobportaldb`

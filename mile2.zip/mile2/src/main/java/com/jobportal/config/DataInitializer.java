package com.jobportal.config;

import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.repository.JobRepository;
import com.jobportal.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final JobRepository jobRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (userRepository.count() > 0) return;

        // ===== Users =====
        User admin = new User();
        admin.setFullName("Admin User");
        admin.setEmail("admin@jobportal.com");
        admin.setPassword(passwordEncoder.encode("admin123"));
        admin.setRole(User.Role.ADMIN);
        userRepository.save(admin);

        User employer1 = new User();
        employer1.setFullName("Tech Corp HR");
        employer1.setEmail("employer@techcorp.com");
        employer1.setPassword(passwordEncoder.encode("employer123"));
        employer1.setRole(User.Role.EMPLOYER);
        employer1.setCompanyName("Tech Corp");
        employer1.setLocation("New York");
        userRepository.save(employer1);

        User employer2 = new User();
        employer2.setFullName("Infosys Recruiter");
        employer2.setEmail("hr@infosys.com");
        employer2.setPassword(passwordEncoder.encode("employer123"));
        employer2.setRole(User.Role.EMPLOYER);
        employer2.setCompanyName("Infosys");
        employer2.setLocation("Bangalore");
        userRepository.save(employer2);

        User student = new User();
        student.setFullName("John Student");
        student.setEmail("student@example.com");
        student.setPassword(passwordEncoder.encode("student123"));
        student.setRole(User.Role.STUDENT);
        student.setLocation("Boston");
        student.setSkills("Java, Spring Boot, SQL");
        student.setBio("Final year CS student looking for backend roles.");
        userRepository.save(student);

        // ===== 10 Jobs =====
        createJob(employer1, "Java Backend Developer",
                "IT", "New York",
                "We are looking for an experienced Java developer to build scalable REST APIs using Spring Boot. You will work with a cross-functional team to design and implement backend services.",
                "Java, Spring Boot, MySQL, REST API",
                "$80,000 - $100,000", "2-4 years", "Full-time");

        createJob(employer1, "Frontend Developer",
                "IT", "Remote",
                "Join our team as a frontend developer to build modern, responsive web applications. You will collaborate with designers and backend engineers.",
                "React, JavaScript, CSS, HTML5",
                "$70,000 - $90,000", "1-3 years", "Full-time");

        createJob(employer1, "DevOps Engineer",
                "IT", "San Francisco",
                "We need a DevOps engineer to manage CI/CD pipelines, cloud infrastructure, and deployment automation. Experience with AWS and Docker is required.",
                "AWS, Docker, Kubernetes, Jenkins, Linux",
                "$90,000 - $120,000", "2-4 years", "Full-time");

        createJob(employer1, "Android Developer",
                "IT", "Austin",
                "Build and maintain high-quality Android applications. You will work on new features, bug fixes, and performance improvements for our mobile platform.",
                "Android, Kotlin, Java, REST API",
                "$75,000 - $95,000", "1-3 years", "Full-time");

        createJob(employer2, "Data Analyst Intern",
                "Data Science", "Bangalore",
                "Exciting internship opportunity in data analytics. You will analyze large datasets, create dashboards, and support business decision-making.",
                "Python, SQL, Excel, Power BI",
                "₹25,000/month", "0-1 years", "Internship");

        createJob(employer2, "Machine Learning Engineer",
                "Data Science", "Hyderabad",
                "Design and implement machine learning models for real-world business problems. Work with large datasets and deploy models to production.",
                "Python, TensorFlow, Scikit-learn, SQL",
                "₹12,00,000 - ₹18,00,000", "2-4 years", "Full-time");

        createJob(employer2, "Full Stack Developer",
                "IT", "Remote",
                "We are hiring a full stack developer to work on both frontend and backend of our SaaS platform. You should be comfortable working across the entire stack.",
                "React, Node.js, Spring Boot, MySQL, Docker",
                "$85,000 - $110,000", "2-4 years", "Full-time");

        createJob(employer2, "UI/UX Designer",
                "Design", "Mumbai",
                "Create intuitive and visually appealing user interfaces. Conduct user research, create wireframes, prototypes, and collaborate with developers.",
                "Figma, Adobe XD, CSS, User Research",
                "₹8,00,000 - ₹12,00,000", "1-3 years", "Full-time");

        createJob(employer1, "Business Analyst",
                "Finance", "Chicago",
                "Analyze business processes and requirements, create detailed documentation, and work with stakeholders to deliver technology solutions.",
                "SQL, Excel, JIRA, Business Analysis, Agile",
                "$65,000 - $85,000", "1-3 years", "Full-time");

        createJob(employer2, "Software Testing Engineer",
                "IT", "Pune",
                "Responsible for manual and automated testing of web and mobile applications. Write test cases, report bugs, and ensure product quality.",
                "Selenium, Java, TestNG, JIRA, SQL",
                "₹6,00,000 - ₹10,00,000", "0-1 years", "Full-time");

        log.info("✅ Sample data initialized with 10 jobs.");
        log.info("Login credentials:");
        log.info("  Admin:    admin@jobportal.com    / admin123");
        log.info("  Employer: employer@techcorp.com  / employer123");
        log.info("  Student:  student@example.com    / student123");
    }

    private void createJob(User employer, String title, String category, String location,
                           String description, String skills, String salary,
                           String experience, String jobType) {
        Job job = new Job();
        job.setTitle(title);
        job.setCategory(category);
        job.setLocation(location);
        job.setDescription(description);
        job.setSkills(skills);
        job.setSalary(salary);
        job.setExperience(experience);
        job.setJobType(jobType);
        job.setEmployer(employer);
        job.setStatus(Job.JobStatus.ACTIVE);
        job.setDeadline(LocalDateTime.now().plusMonths(1));
        jobRepository.save(job);
    }
}

package com.jobportal.controller;

import com.jobportal.entity.Application;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.service.ApplicationService;
import com.jobportal.service.JobService;
import com.jobportal.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/employer")
@PreAuthorize("hasRole('EMPLOYER')")
@RequiredArgsConstructor
public class EmployerController {

    private final UserService userService;
    private final JobService jobService;
    private final ApplicationService applicationService;

    private User getCurrentUser(UserDetails userDetails) {
        return userService.findByEmail(userDetails.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User employer = getCurrentUser(userDetails);
        model.addAttribute("employer", employer);
        model.addAttribute("jobs", jobService.findByEmployer(employer));
        model.addAttribute("totalJobs", jobService.countByEmployer(employer));
        model.addAttribute("totalApplications", applicationService.countByEmployerJobs(employer));
        return "employer/dashboard";
    }

    @GetMapping("/jobs/new")
    public String newJobForm(Model model) {
        model.addAttribute("job", new Job());
        return "employer/job-form";
    }

    @PostMapping("/jobs/new")
    public String postJob(@Valid @ModelAttribute("job") Job job,
                          BindingResult result,
                          @AuthenticationPrincipal UserDetails userDetails,
                          RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) return "employer/job-form";
        User employer = getCurrentUser(userDetails);
        job.setEmployer(employer);
        jobService.postJob(job);
        redirectAttributes.addFlashAttribute("success", "Job posted successfully!");
        return "redirect:/employer/dashboard";
    }

    @GetMapping("/jobs/{id}/edit")
    public String editJobForm(@PathVariable Long id, Model model) {
        model.addAttribute("job", jobService.findById(id));
        return "employer/job-form";
    }

    @PostMapping("/jobs/{id}/edit")
    public String updateJob(@PathVariable Long id,
                            @Valid @ModelAttribute("job") Job job,
                            BindingResult result,
                            @AuthenticationPrincipal UserDetails userDetails,
                            RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) return "employer/job-form";
        job.setId(id);
        job.setEmployer(getCurrentUser(userDetails));
        jobService.updateJob(job);
        redirectAttributes.addFlashAttribute("success", "Job updated successfully!");
        return "redirect:/employer/dashboard";
    }

    @PostMapping("/jobs/{id}/delete")
    public String deleteJob(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        jobService.deleteJob(id);
        redirectAttributes.addFlashAttribute("success", "Job deleted.");
        return "redirect:/employer/dashboard";
    }

    @GetMapping("/jobs/{id}/applicants")
    public String viewApplicants(@PathVariable Long id, Model model) {
        Job job = jobService.findById(id);
        model.addAttribute("job", job);
        model.addAttribute("applications", applicationService.findByJob(job));
        return "employer/applicants";
    }

    @PostMapping("/applications/{id}/status")
    public String updateApplicationStatus(@PathVariable Long id,
                                          @RequestParam Application.ApplicationStatus status,
                                          RedirectAttributes redirectAttributes) {
        Application app = applicationService.updateStatus(id, status);
        redirectAttributes.addFlashAttribute("success", "Application status updated to " + status);
        return "redirect:/employer/jobs/" + app.getJob().getId() + "/applicants";
    }
}

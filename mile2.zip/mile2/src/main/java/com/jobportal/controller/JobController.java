package com.jobportal.controller;

import com.jobportal.entity.Job;
import com.jobportal.service.JobService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/jobs")
@RequiredArgsConstructor
public class JobController {

    private final JobService jobService;

    @GetMapping
    public String listJobs(Model model) {
        model.addAttribute("jobs", jobService.findAllActive());
        return "jobs/list";
    }

    @GetMapping("/search")
    public String searchJobs(@RequestParam(required = false) String keyword,
                             @RequestParam(required = false) String category,
                             @RequestParam(required = false) String location,
                             @RequestParam(required = false) String experience,
                             Model model) {
        List<Job> jobs = jobService.searchJobs(keyword, category, location, experience);
        model.addAttribute("jobs", jobs);
        model.addAttribute("keyword", keyword);
        model.addAttribute("category", category);
        model.addAttribute("location", location);
        model.addAttribute("experience", experience);
        return "jobs/list";
    }

    @GetMapping("/{id}")
    public String jobDetail(@PathVariable Long id, Model model) {
        model.addAttribute("job", jobService.findById(id));
        return "jobs/detail";
    }
}

package com.jobportal.controller;

import com.jobportal.entity.Application;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.service.ApplicationService;
import com.jobportal.service.JobService;
import com.jobportal.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;

@Controller
@RequestMapping("/student")
@PreAuthorize("hasRole('STUDENT')")
@RequiredArgsConstructor
public class StudentController {

    private final UserService userService;
    private final JobService jobService;
    private final ApplicationService applicationService;

    private User getCurrentUser(UserDetails userDetails) {
        return userService.findByEmail(userDetails.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = getCurrentUser(userDetails);
        model.addAttribute("user", user);
        model.addAttribute("applications", applicationService.findByApplicant(user));
        model.addAttribute("totalApplications", applicationService.countByApplicant(user));
        return "student/dashboard";
    }

    @GetMapping("/profile")
    public String profile(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        model.addAttribute("user", getCurrentUser(userDetails));
        return "student/profile";
    }

    @PostMapping("/profile")
    public String updateProfile(@AuthenticationPrincipal UserDetails userDetails,
                                @ModelAttribute User updated,
                                RedirectAttributes redirectAttributes) {
        User current = getCurrentUser(userDetails);
        updated.setId(current.getId());
        userService.updateProfile(updated);
        redirectAttributes.addFlashAttribute("success", "Profile updated successfully.");
        return "redirect:/student/profile";
    }

    /**
     * Upload resume — stored as LONGBLOB in MySQL users table
     */
    @PostMapping("/resume/upload")
    public String uploadResume(@AuthenticationPrincipal UserDetails userDetails,
                               @RequestParam("resume") MultipartFile file,
                               RedirectAttributes redirectAttributes) throws IOException {
        if (file.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Please select a file to upload.");
            return "redirect:/student/profile";
        }
        User user = getCurrentUser(userDetails);
        userService.uploadResume(user.getId(), file);
        redirectAttributes.addFlashAttribute("success",
                "Resume '" + file.getOriginalFilename() + "' uploaded and saved to database successfully.");
        return "redirect:/student/profile";
    }

    /**
     * Download resume from database
     */
    @GetMapping("/resume/download")
    public ResponseEntity<byte[]> downloadResume(@AuthenticationPrincipal UserDetails userDetails) {
        User user = getCurrentUser(userDetails);
        if (user.getResumeData() == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(
                        user.getResumeContentType() != null ? user.getResumeContentType() : "application/octet-stream"))
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + user.getResumeFileName() + "\"")
                .body(user.getResumeData());
    }

    @GetMapping("/apply/{jobId}")
    public String applyForm(@PathVariable Long jobId,
                            @AuthenticationPrincipal UserDetails userDetails,
                            Model model) {
        model.addAttribute("job", jobService.findById(jobId));
        model.addAttribute("user", getCurrentUser(userDetails));
        return "student/apply";
    }

    @PostMapping("/apply/{jobId}")
    public String applyJob(@PathVariable Long jobId,
                           @AuthenticationPrincipal UserDetails userDetails,
                           @RequestParam(required = false) String coverLetter,
                           RedirectAttributes redirectAttributes) {
        User user = getCurrentUser(userDetails);
        Job job = jobService.findById(jobId);
        applicationService.apply(job, user, coverLetter);
        redirectAttributes.addFlashAttribute("success", "Application submitted successfully!");
        return "redirect:/student/dashboard";
    }

    @GetMapping("/applications")
    public String myApplications(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = getCurrentUser(userDetails);
        model.addAttribute("applications", applicationService.findByApplicant(user));
        return "student/applications";
    }
}

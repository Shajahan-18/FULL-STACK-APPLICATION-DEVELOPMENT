package com.jobportal.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "jobs")
@Data
@NoArgsConstructor
public class Job {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String title;

    @NotBlank
    @Column(columnDefinition = "TEXT")
    private String description;

    @NotBlank
    private String category;

    @NotBlank
    private String location;

    private String skills;       // required skills (comma-separated)
    private String salary;
    private String experience;   // e.g. "0-2 years"
    private String jobType;      // Full-time, Part-time, Internship

    @Enumerated(EnumType.STRING)
    private JobStatus status = JobStatus.ACTIVE;

    @Column(updatable = false)
    private LocalDateTime postedAt = LocalDateTime.now();

    private LocalDateTime deadline;

    // Many jobs -> one employer
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employer_id")
    @NotNull
    private User employer;

    // One job -> many applications
    @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Application> applications;

    public enum JobStatus {
        ACTIVE, CLOSED
    }
}

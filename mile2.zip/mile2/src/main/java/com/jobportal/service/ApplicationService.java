package com.jobportal.service;

import com.jobportal.entity.Application;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.repository.ApplicationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ApplicationService {

    private final ApplicationRepository applicationRepository;
    private final EmailService emailService;

    public Application apply(Job job, User applicant, String coverLetter) {
        if (applicationRepository.existsByJobAndApplicant(job, applicant)) {
            throw new IllegalStateException("You have already applied for this job.");
        }
        Application app = new Application();
        app.setJob(job);
        app.setApplicant(applicant);
        app.setCoverLetter(coverLetter);
        return applicationRepository.save(app);
    }

    public List<Application> findByApplicant(User applicant) {
        return applicationRepository.findByApplicant(applicant);
    }

    public List<Application> findByJob(Job job) {
        return applicationRepository.findByJob(job);
    }

    public Application findById(Long id) {
        return applicationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Application not found: " + id));
    }

    public Application updateStatus(Long applicationId, Application.ApplicationStatus newStatus) {
        Application app = findById(applicationId);
        app.setStatus(newStatus);
        Application saved = applicationRepository.save(app);

        // Send email notification on shortlist
        if (newStatus == Application.ApplicationStatus.SHORTLISTED) {
            emailService.sendShortlistNotification(
                    saved.getApplicant().getEmail(),
                    saved.getApplicant().getFullName(),
                    saved.getJob().getTitle()
            );
        }
        return saved;
    }

    public long countByApplicant(User applicant) {
        return applicationRepository.countByApplicant(applicant);
    }

    public long countTotal() {
        return applicationRepository.count();
    }

    public long countShortlisted() {
        return applicationRepository.countByStatus(Application.ApplicationStatus.SHORTLISTED);
    }

    public long countByEmployerJobs(User employer) {
        return applicationRepository.countByJobEmployer(employer);
    }
}

package com.jobportal.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class EmailService {

    public void sendShortlistNotification(String toEmail, String name, String jobTitle) {
        // Email sending is optional - logs notification instead
        log.info("NOTIFICATION: {} ({}) has been shortlisted for '{}'", name, toEmail, jobTitle);
    }

    public void sendApplicationConfirmation(String toEmail, String name, String jobTitle) {
        log.info("NOTIFICATION: Application confirmation for {} ({}) - '{}'", name, toEmail, jobTitle);
    }
}

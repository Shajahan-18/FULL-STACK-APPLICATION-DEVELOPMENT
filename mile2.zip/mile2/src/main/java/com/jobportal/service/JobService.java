package com.jobportal.service;

import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.repository.JobRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class JobService {

    private final JobRepository jobRepository;

    public Job postJob(Job job) {
        return jobRepository.save(job);
    }

    public Job findById(Long id) {
        return jobRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Job not found: " + id));
    }

    public List<Job> findAllActive() {
        return jobRepository.findByStatus(Job.JobStatus.ACTIVE);
    }

    public List<Job> findByEmployer(User employer) {
        return jobRepository.findByEmployer(employer);
    }

    public List<Job> searchJobs(String keyword, String category, String location, String experience) {
        String kw = (keyword != null && keyword.isBlank()) ? null : keyword;
        String cat = (category != null && category.isBlank()) ? null : category;
        String loc = (location != null && location.isBlank()) ? null : location;
        String exp = (experience != null && experience.isBlank()) ? null : experience;
        return jobRepository.searchJobs(kw, cat, loc, exp);
    }

    public Job updateJob(Job updated) {
        Job existing = findById(updated.getId());
        existing.setTitle(updated.getTitle());
        existing.setDescription(updated.getDescription());
        existing.setCategory(updated.getCategory());
        existing.setLocation(updated.getLocation());
        existing.setSkills(updated.getSkills());
        existing.setSalary(updated.getSalary());
        existing.setExperience(updated.getExperience());
        existing.setJobType(updated.getJobType());
        existing.setDeadline(updated.getDeadline());
        existing.setStatus(updated.getStatus());
        return jobRepository.save(existing);
    }

    public void deleteJob(Long id) {
        jobRepository.deleteById(id);
    }

    public long countActive() {
        return jobRepository.countByStatus(Job.JobStatus.ACTIVE);
    }

    public long countByEmployer(User employer) {
        return jobRepository.countByEmployer(employer);
    }

    public List<Job> findAll() {
        return jobRepository.findAll();
    }
}

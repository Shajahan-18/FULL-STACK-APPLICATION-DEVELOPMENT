package com.jobportal.service;

import com.jobportal.entity.User;
import com.jobportal.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public User register(User user) {
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new IllegalArgumentException("Email already registered: " + user.getEmail());
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepository.save(user);
    }

    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public User findById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found: " + id));
    }

    public User updateProfile(User updated) {
        User existing = findById(updated.getId());
        existing.setFullName(updated.getFullName());
        existing.setPhone(updated.getPhone());
        existing.setLocation(updated.getLocation());
        existing.setSkills(updated.getSkills());
        existing.setBio(updated.getBio());
        if (updated.getCompanyName() != null) {
            existing.setCompanyName(updated.getCompanyName());
        }
        return userRepository.save(existing);
    }

    /**
     * Stores the resume file directly in the MySQL database as a BLOB.
     * Visible in MySQL Workbench under the 'users' table columns:
     *   resume_file_name, resume_content_type, resume_data
     */
    public void uploadResume(Long userId, MultipartFile file) throws IOException {
        User user = findById(userId);
        user.setResumeFileName(file.getOriginalFilename());
        user.setResumeContentType(file.getContentType());
        user.setResumeData(file.getBytes());   // store bytes in LONGBLOB column
        userRepository.save(user);
    }

    /**
     * Returns the resume bytes for download.
     */
    public User getUserWithResume(Long userId) {
        return findById(userId);
    }

    public List<User> findAll() {
        return userRepository.findAll();
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
}

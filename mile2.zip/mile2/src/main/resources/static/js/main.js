// ===== Live Table/Grid Filter =====
document.addEventListener('DOMContentLoaded', function () {

    const filterInput = document.getElementById('liveSearch');
    if (!filterInput) return;

    filterInput.addEventListener('input', function () {
        const query = this.value.toLowerCase().trim();

        // Filter table rows
        const table = document.querySelector('.data-table');
        if (table) {
            const rows = table.querySelectorAll('tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(query) ? '' : 'none';
            });
        }

        // Filter job cards
        const jobGrid = document.getElementById('jobGrid');
        if (jobGrid) {
            const cards = jobGrid.querySelectorAll('.job-card');
            cards.forEach(card => {
                const title = (card.dataset.title || '').toLowerCase();
                const company = (card.dataset.company || '').toLowerCase();
                const text = card.textContent.toLowerCase();
                card.style.display = (title.includes(query) || company.includes(query) || text.includes(query)) ? '' : 'none';
            });
        }

        // Filter applicant cards
        const applicantsGrid = document.getElementById('applicantsGrid');
        if (applicantsGrid) {
            const cards = applicantsGrid.querySelectorAll('.applicant-card');
            cards.forEach(card => {
                const text = card.textContent.toLowerCase();
                card.style.display = text.includes(query) ? '' : 'none';
            });
        }
    });
});

// ===== Auto-dismiss alerts =====
document.addEventListener('DOMContentLoaded', function () {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 4000);
    });
});
